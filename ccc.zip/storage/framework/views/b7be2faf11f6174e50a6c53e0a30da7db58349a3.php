<?php $__env->startSection('content'); ?>

<div class="container">
  <div class="column is-8 is-offset-2">
    <div class="panel">
      <div class="panel-heading">
        List of all Friends
      </div>
      <?php $__empty_1 = true; $__currentLoopData = $friends; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $friend): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <a href="<?php echo e(route('chat.show', $friend->id)); ?>" class="panel-block" style="justify-content: space-between;">
          <div class=""><?php echo e($friend->name); ?></div>
          <onlineuser v-bind:friend="<?php echo e($friend); ?>" v-bind:onlineusers="onlineUsers"></onlineuser>
        </a>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <div class="panel-block">
          You don't have any friends
        </div>
      <?php endif; ?>
    </div>
  </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>