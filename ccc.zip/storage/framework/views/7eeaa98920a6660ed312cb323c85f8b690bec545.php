<?php $__env->startSection('content'); ?>
    <audio id="ChatAudio">
        <source src="<?php echo e(asset('sounds/chat.mp3')); ?>">
    </audio>
    <meta name="friendId" content="<?php echo e($friend->id); ?>">
    <div class="container">
        <div class="column is-8 is-offset-2">
            <div class="panel">
                <div class="panel-heading">
                    <?php echo e($friend->name); ?>

                    <div class="contain is-pulled-right">
                        <a href="<?php echo e(url('/chat')); ?>" class="is-link"><i class="fa fa-arrow-left"></i> Go Back</a>
                    </div>
                    <chat v-bind:chats="chats" v-bind:userid="<?php echo e(Auth::user()->id); ?>" v-bind:friendid="<?php echo e($friend->id); ?>"></chat>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>