
require('bulma-extensions/bulma-accordion/dist/bulma-accordion');
require('bulma-extensions/bulma-calendar/dist/bulma-calendar');
require('bulma-extensions/bulma-carousel/dist/bulma-carousel');
require('bulma-extensions/bulma-iconpicker/dist/bulma-iconpicker');
require('bulma-extensions/bulma-quickview/dist/bulma-quickview');
require('bulma-extensions/bulma-slider/dist/bulma-slider');
require('bulma-extensions/bulma-steps/dist/bulma-steps');
require('bulma-extensions/bulma-tagsinput/dist/bulma-tagsinput');
